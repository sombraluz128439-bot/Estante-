# Minhas Alas v3
App de escrita, mundos, histórias, músicas e alas personalizadas (estrelas, notas, progresso, batalha). Cadeado fechado = nunca mais pode ser apagado.

## Publicar no GitHub
1. Crie um repositório e envie TODO o conteúdo desta pasta (inclusive `.github`).
2. **Settings → Pages → Source: GitHub Actions.** O app fica online e instalável (Chrome → "Adicionar à tela inicial").
3. **Actions → Build Minhas Alas Android APK → Run workflow** gera o APK em *Artifacts*.

Localmente: `npm install && npm start`. Faça backup (aba Mais) de vez em quando.
