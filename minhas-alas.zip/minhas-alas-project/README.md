# Minhas Alas — projeto reconstruído

Este projeto recupera a interface web embutida no APK enviado e prepara uma base editável para continuar o desenvolvimento.

## O que foi recuperado
- Interface original do Minhas Alas (HTML/CSS/JavaScript embutidos no APK Capacitor).
- Editor de livros e músicas, ideias, cores/temas, estatísticas, anexos, versões, fichas e backup JSON.
- Configuração Capacitor recuperada do APK.

## Novidades adicionadas nesta reconstrução
- Aba **Alas** para criar espaços personalizados.
- Cada ala aceita conteúdos livres com título e texto.
- Critérios de avaliação configuráveis por ala: notas numéricas, estrelas ou texto.
- Cadeados para proteger alas e conteúdos contra exclusão acidental.
- Exportação individual de conteúdo e backup geral.

## Limitações importantes
- O APK original não contém o projeto Android/Gradle completo nem o histórico Git; esta é uma reconstrução do conteúdo web recuperável, não uma recuperação integral do código-fonte original.
- O cadeado é uma proteção contra exclusão dentro da interface, não uma garantia criptográfica de que dados jamais possam ser apagados. Faça backups periódicos.
- Este pacote contém o projeto-fonte web. Ainda não é um APK novo compilado e ainda não foi publicado no GitHub.

## Executar localmente
Requer Node.js instalado:
```bash
npm install
npm run start
```

## Próxima etapa Android
Adicionar a plataforma Android a um projeto Capacitor configurado e compilar com Android Studio/SDK. O APK de origem foi mantido apenas como referência em `app-debug.apk`; não o instale como versão nova.


## Gerar APK pelo GitHub Actions

O projeto agora inclui `@capacitor/android` na mesma linha de versão do Capacitor 6 e o workflow `.github/workflows/android.yml`.

1. Envie o conteúdo desta pasta para um repositório GitHub.
2. Garanta que o branch principal se chame `main` ou `master`.
3. Abra a aba **Actions** do repositório.
4. Execute **Build Minhas Alas Android APK** em **Run workflow**, ou faça um push para `main`/`master`.
5. Quando terminar, abra a execução e baixe o artefato **minhas-alas-debug-apk**.

O workflow instala as dependências, adiciona a plataforma Android, sincroniza os arquivos e compila um APK de depuração. Este pacote não contém um APK novo compilado; o APK será gerado pelo GitHub Actions.
