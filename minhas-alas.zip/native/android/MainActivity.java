package com.minhas.alas.studio;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SpeechDictationPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
