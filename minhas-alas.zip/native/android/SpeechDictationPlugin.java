package com.minhas.alas.studio;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.ArrayList;

/** Uses the installed Android recognition provider. No audio files are created by this plugin. */
@CapacitorPlugin(name = "SpeechDictation", permissions = {
    @Permission(alias = "microphone", strings = {Manifest.permission.RECORD_AUDIO})
})
public class SpeechDictationPlugin extends Plugin {
    private SpeechRecognizer recognizer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable timeout;
    private int session = 0;

    @PluginMethod
    public void start(PluginCall call) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            requestPermissionForAlias("microphone", call, "microphoneResult");
        } else begin(call);
    }

    @PermissionCallback
    private void microphoneResult(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) begin(call);
        else call.reject("Microfone não autorizado. Permita o acesso nas configurações do aplicativo.");
    }

    private void begin(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
                call.reject("Nenhum serviço de reconhecimento de fala instalado. Ative ou instale um serviço de voz nas configurações do Android.");
                return;
            }
            release();
            final int currentSession = ++session;
            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
                recognizer.setRecognitionListener(new RecognitionListener() {
                    private boolean current() { return session == currentSession && recognizer != null; }
                    @Override public void onReadyForSpeech(Bundle params) { }
                    @Override public void onBeginningOfSpeech() { }
                    @Override public void onRmsChanged(float rmsdB) { }
                    @Override public void onBufferReceived(byte[] buffer) { }
                    @Override public void onEndOfSpeech() { if (current()) scheduleTimeout(currentSession); }
                    @Override public void onError(int error) {
                        if (!current()) return;
                        emitError(errorMessage(error));
                        release();
                    }
                    @Override public void onResults(Bundle result) {
                        if (!current()) return;
                        ArrayList<String> texts = result.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (texts == null || texts.isEmpty()) emitError("Nenhuma fala reconhecida. Tente novamente.");
                        else {
                            JSObject event = new JSObject();
                            event.put("text", texts.get(0)); event.put("final", true);
                            notifyListeners("speechResult", event);
                        }
                        release();
                    }
                    @Override public void onPartialResults(Bundle result) {
                        if (!current()) return;
                        ArrayList<String> texts = result.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (texts == null || texts.isEmpty()) return;
                        JSObject event = new JSObject();
                        event.put("text", texts.get(0)); event.put("final", false);
                        notifyListeners("speechResult", event);
                    }
                    @Override public void onEvent(int eventType, Bundle params) { }
                });
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, call.getString("language", "pt-BR"));
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                recognizer.startListening(intent);
                call.resolve();
            } catch (Exception e) {
                release();
                call.reject("Não foi possível iniciar o reconhecimento de voz: " + e.getMessage());
            }
        });
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if (recognizer != null) {
                recognizer.stopListening();
                scheduleTimeout(session);
            }
            call.resolve();
        });
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        getActivity().runOnUiThread(() -> { release(); call.resolve(); });
    }

    private void scheduleTimeout(int expected) {
        if (timeout != null) handler.removeCallbacks(timeout);
        timeout = () -> {
            if (session != expected || recognizer == null) return;
            emitError("O serviço de voz demorou para responder. A transcrição parcial pode ser copiada ou inserida manualmente.");
            release();
        };
        handler.postDelayed(timeout, 12000);
    }

    private void emitError(String message) {
        JSObject event = new JSObject(); event.put("message", message);
        notifyListeners("speechError", event);
    }

    private void release() {
        session++;
        if (timeout != null) { handler.removeCallbacks(timeout); timeout = null; }
        if (recognizer != null) {
            SpeechRecognizer old = recognizer; recognizer = null;
            old.cancel(); old.destroy();
        }
    }

    private String errorMessage(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microfone não autorizado nas permissões do Android.";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Serviço de voz sem conexão. Verifique a internet.";
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "Nenhuma fala reconhecida. Tente falar mais perto do microfone.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "O microfone está ocupado. Encerre outros apps de voz e tente novamente.";
            case SpeechRecognizer.ERROR_AUDIO: return "Não foi possível captar áudio do microfone.";
            default: return "O serviço de voz encerrou a sessão (código " + code + "). Tente novamente.";
        }
    }

    @Override protected void handleOnPause() {
        if (recognizer != null) emitError("Ditado interrompido ao sair do aplicativo. Revise a transcrição parcial.");
        release();
    }
    @Override protected void handleOnDestroy() { release(); }
}
