import {readFileSync,existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';
process.chdir(resolve(import.meta.dirname,'..'));
for(const file of ['www/studio.js','www/studio-core.js','www/sw.js'])execFileSync(process.execPath,['--check',file],{stdio:'inherit'});
const html=readFileSync('www/index.html','utf8');const scripts=[...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(x=>x[1]).filter(Boolean);
for(const script of scripts){new Function(script);}
for(const file of ['www/studio.css','www/GUIA.html','www/manifest.webmanifest','www/icon.svg','native/android/SpeechDictationPlugin.java','native/android/MainActivity.java','.github/workflows/android.yml','.github/workflows/pages.yml'])if(!existsSync(file))throw Error('Arquivo ausente: '+file);
JSON.parse(readFileSync('www/manifest.webmanifest','utf8'));
console.log('Sintaxe JavaScript, scripts da interface e estrutura verificadas.');
